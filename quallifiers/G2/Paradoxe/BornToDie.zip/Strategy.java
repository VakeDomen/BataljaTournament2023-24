public interface Strategy {
    void earlyGame(State var1);

    void endGame(State var1);
}